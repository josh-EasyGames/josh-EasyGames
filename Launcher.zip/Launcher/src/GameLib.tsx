import { createResource, type Component, For, createSignal } from "solid-js";
import "./GameLib.css" ; 
import Loader from "./Loader";
import hilo from '../src/assets/hilo.jpg';
import poker from '../src/assets/poker.jpg';

const GameLib : Component = () => {

const [showIframe , setIframeShow] = createSignal(false) ; 
const [ifameURL, setiFrame] = createSignal("https://www.google.com") ; 
const [isLoading , setLoading] = createSignal(false)

const fetchGamesData = async () => {
    const response = await fetch("https://easy-public.easygamesdemo.co.za/api/Public/GameList") ; 
    return response.json() ;
}

const fecthGameLaucherData = async(iframeUrl : string) =>{
    const response = await fetch(`https://easy-public.easygamesdemo.co.za/api/Public/GameURL?playerId=123&launchURL=${iframeUrl}`)
    return response.text() ; 
}

const fecthplaytech = async() => {
    const response = await fetch("https://easy-public.easygamesdemo.co.za/api/Public/playtech/gamelist")
    return response.json();
}

const fetchIFrame  = async(code :string) => {
    const response  =await fetch(`https://easy-public.easygamesdemo.co.za/api/Public/playtech/launchCodes?lobby=${code}`) ; 
    return response.text() ; 
}

const launchIFrame = async (url  :string) =>{
    setiFrame(url);
    setLoading(true) ; 
    const res = await  fecthGameLaucherData(url) ;
    setLoading(false) ; 
    setiFrame(res) ; 
    setIframeShow(true); 
}

const launchPlayTechIFrame = async (url : string) => {
    
    const res =  await fetchIFrame(url) ; 
    window.open(res) ; 


}

const[playtechAssets] = createResource(fecthplaytech); 
const[imageData] = createResource(fetchGamesData) ; 

return isLoading() ? <Loader/> :(
    <>
        <center><h1>Games</h1></center> 

        {playtechAssets.loading &&(
           <Loader/>
        )}

        {playtechAssets.error && (
            <p>An error occured</p>
        )}
       <center> <div class="imageDisplay">
            {
                playtechAssets() && (
                    <For each={playtechAssets()}>
                { (image) =>(<>

                        <div class="imageHolder" onClick={async() => {launchPlayTechIFrame(image.lobbyCode)} }>
                            <div class="imageTitle">
                                <p>  {image.lobbyName}</p>
                            </div>
                            
<img class="imageData" src={image.imageID % 2 == 0 ?  hilo : poker} alt={image.description} srcset="" />                            
                        </div>
                 
                </>)}

            </For>


                )
            }


        {/* {imageData()  && (
            <For each={imageData().gameAssets}>
                { (image) =>(<>

                        <div class="imageHolder" onClick={async() => {launchIFrame(image.url)} }>
                            <div class="imageTitle">
                                <p>  {image.description}</p>
                            </div>
                            
                            <img class="imageData" src={image.imageURL} alt={image.description} srcset="" />
                            
                        </div>
                 
                </>)}

            </For>

        )} */}
        {
            showIframe() && (
                <>
                    <button onClick={() => setIframeShow(false)} class="buttonClose">Close</button>
                    <iframe class="iframe" src={ifameURL()}  />
                </>
            )
        }
        



        </div>
        </center>
        
    </>

)

}

export default GameLib ; 