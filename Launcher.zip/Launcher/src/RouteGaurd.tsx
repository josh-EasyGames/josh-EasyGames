import {Outlet , useNavigate} from "@solidjs/router" ; 
import { createEffect ,type Component} from "solid-js";



const RouteGaurd :Component  = () => {

    const navigate  = useNavigate() ;     
    const token = sessionStorage.getItem('token') ; 
    
    createEffect(() => {
        if(!token){
            navigate('/login' , {replace:true})
        }
    })

    return (
        <div>
            This is a protected route 
            <Outlet/>
        </div>


    )
}

export default RouteGaurd ; 