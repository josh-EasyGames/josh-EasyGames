/* @refresh reload */
import { render } from 'solid-js/web';
import {Router,  Route ,  Routes} from "@solidjs/router" ; 

import './index.css';
import App from './App';
import Login from './Login';
import GameLib from './GameLib';
import LandingPage from './LandingPage/LandingPage';
import { ClientConfig } from './config/config';

const root = document.getElementById('root');

if (import.meta.env.DEV && !(root instanceof HTMLElement)) {
  throw new Error(
    'Root element not found. Did you forget to add it to your index.html? Or maybe the id attribute got misspelled?',
  );
}






// const GamesAvailableRequest = async() => {
//   const response = await fetch("https://easy-public.easygamesdemo.co.za/api/Public/playtech/gamelist")
//   return response.json();
// }
// var Games = await  GamesAvailableRequest() ; 


// const preloadImage = (src: string) => 
//   new Promise((resolve, reject) => {

//     fetch(`https://easy-public.easygamesdemo.co.za/api/Public/image/${src}`)
//       .then((res) => res.blob())
//         .then(a => console.log(a)); 

//     resolve("")


//   });


const searchParams = new URLSearchParams(window.location.search);

var token  = searchParams.get("aggrt")  ; 

localStorage.setItem("token" , token) ; 

  render(
    () =>( 
      <LandingPage/>
      // <GameLib/>
    
    )
    , root!);





