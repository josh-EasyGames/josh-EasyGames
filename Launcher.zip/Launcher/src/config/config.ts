export const  ClientConfig   = {
    baseUrl : "https://easy-public.easygamesdemo.co.za"
}