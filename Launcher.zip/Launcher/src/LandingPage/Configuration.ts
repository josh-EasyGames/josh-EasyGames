import { lazy } from "solid-js";

import ThreeCardBrag from "../assets/3CardBrag/3cardBrag.png";
import AbsolutelyMammoth from "../assets/AbsolutelyMammoth/ABsolutelyMammoth.png";
import AlohawaiiCashCollet from "../assets/AlohawaiiCashCollect/AlohawaiiCashCollect.png";
import AnacondaUncoiled from "../assets/AnacondaUncoiled/AnacondaUncoiled.png";
import AnacondaWild from "../assets/AnacondaWild/icon_gameLarge_01_512.png";
import AnacondWildTwo from "../assets/AnacondaWild2/Anaconda_Wild_II_icon_nocharacter_gameLarge_01_512x512.png";
import AronwanasLuck from "../assets/AronwanasLuck/arowanas-luck_ch_icon_game-large-01_512.png";
import AtlanticCashCollect from "../assets/AtlantisCashCollect/char_512X512.png";
import AztecaBonusLines from "../assets/AztecaBonusLines/Marketing Kit_Icons Without Character_icon_nocharacter_gameLarge_01_512x512.png8.png";
import BeeFrenzyThundershot from "../assets/BeeFrenzyThundershots/BeeFrenzy_GameIcon512X512.png";

const ImageMappings = {
  1: {
    image: ThreeCardBrag,
    name: "3 Card Brag",
  },
  2: {
    image: AbsolutelyMammoth,
    name: "Absolutely Mammoth",
  },
  3: {
    image: AlohawaiiCashCollet,
    name: "Alohawaii Cash Collet",
  },
  4: {
    image: AnacondaUncoiled,
    name: "Anaconda Uncoiled",
  },
  5: {
    image: AnacondaWild,
    name: "Anaconda Wild",
  },
  6: {
    image: AnacondWildTwo,
    name: "Anaconda Wild Two",
  },
  7: { image: AronwanasLuck, name: "Aronwanas Luck" },
  8: { image: AtlanticCashCollect, name: "Atlantis Cash Collect" },
  9: { image: AztecaBonusLines, name: "Azteca Bonus Lines" },
  10: { image: BeeFrenzyThundershot, name: "Bee Frenzy Thindershot" },
};

export default ImageMappings;
