import { Component, For, createResource, createSignal } from "solid-js";
import ImageMappings from "./Configuration"

import "./LandingPage.css";
import all from '../assets/heart.svg' ; 
import pop from '../assets/flame.svg' ; 
import newl from '../assets/game.svg' ; 
import fav from '../assets/new.svg' ; 
import CompanyLogo from "../assets/logo-gold.png"; 
import Flag from "../assets/gb.svg" ; 
import Loader from "../Loader";
import {ClientConfig} from '../config/config' ; 

import allImage from '../assets/GameAssets/all.png' ; 
import popularImage from '../assets/GameAssets/popular.png' ; 
import newImage from '../assets/GameAssets/new.png' ; 
import favouriteImage from  '../assets/GameAssets/favourite.png';
import slotImage from '../assets/GameAssets/slots.png' ; 
import tableImage from '../assets/GameAssets/table.png' ; 
import blackjackImage from "../assets/GameAssets/blackjack.png" ; 
import rouletteImage from "../assets/GameAssets/roulette.png" ; 
import pokerImage from "../assets/GameAssets/poker.png" ; 
import scratchAndWinImage from "../assets/GameAssets/scratch.png" ;
import logoGold from "../assets/GameAssets/logo-gold.png";

const LandingPage : Component  = () => {


const [getSearch , setSearch] = createSignal('') ; 
const [getGameList  ,setGameList] = createSignal([]) ; 

const HandleSearchInput = (event: Event) =>  {
	
	setSearch(event.target.value);	

	if(getSearch().trim() == "" || getSearch().trim() == '<empty string>' ){
		mutate(getGameList()) ; 
		return ; 
	}
	console.log(getSearch()) ;
	console.log(getGameList()); 
	var mutated = getGameList().filter((f:any) => f.lobbyName.toUpperCase().includes(getSearch().toUpperCase())) 
	console.log(mutated) ; 
	mutate(mutated)
	console.log(GamesAvailable());

	

}


const getAllGames = () => {
	setSearch("") ; 
	mutate(getGameList()) ; 
} 

const getAllPopular = () => {
	setSearch("") ; 
	var mutated = GamesAvailable().filter((x : any) => {
		return x.meta != null && x.meta.split(" ").filter((x : any) =>  x == "Popular" || x == 'POPULAR').length > 0 ; 
	});

	mutate(mutated);
}

const getAllNew = () => {
	setSearch("") ; 
	var mutated = GamesAvailable().filter((x : any) => {
		return x.meta != null && x.meta.split(" ").filter((x : any) =>  x == "New" || x == 'NEW').length > 0 ; 
	});
	console.log("mutated" , mutated) ; 
	mutate(mutated);

}



const getAllGamesForGameType =  (id : any) => {

	mutate(getGameList().filter((x:any) => x.gtid == id)) ; 


}

const GamesAvailableRequest = async() => {
	var platfrom =  window.innerWidth < 540 ? "MOB" : 'WEB' ;    
    const response = await fetch(`${ClientConfig.baseUrl}/api/Public/playtech/gamelist/${platfrom}`)
    var res =  response.json();
	var resCopy = res ; 
	setGameList(await resCopy) ; 

	return res ; 

}

const fetchIFrame  = async(code :string, username: string) => {

	const token = localStorage.getItem("token")
    const response  =await fetch(`${ClientConfig.baseUrl}/api/Public/playtech/launchCodes?gameName=${code}&token=${token}`) ; 
    return response.text() ; 
}

const LaunchGame = async (url : string) => {
    
	const urlParams = new URLSearchParams(window.location.search);
	let username : any = '';
	username = urlParams.get('u');
	console.log(username);
    const res =  await fetchIFrame(url, username) ; 
    window.open(res) ; 


}


const getTag =  (game  : any ) => {
 
	if(game.meta ==  null ){
		return 
	}

	if(game.meta.split(" ").filter((x : any) => x == 'NEW' || x == "Popular" || x == 'New' || x == 'POPULAR')){
		
		var t = game.meta.split(" ").filter((x : any) => x == 'NEW' || x == "Popular" || x == 'New' || x == 'POPULAR')[0]
		
		return t ; 
	}
	return null 

}

const [GamesAvailable,{mutate,refetch}] = createResource(GamesAvailableRequest) ; 

 


return   (

	<>

	{GamesAvailable.loading && (
		<Loader/>
	)}


	
		{GamesAvailable() && (
			
			<div class="LandingPage">
				<img  src={logoGold} alt="" class="cl-mob"  />     
			<div class="LandingToolbar">           
				<div class="searchAndLanguage">
					<input value={getSearch()} onChange={HandleSearchInput} class="SearchBar" type="text" name="" id="" placeholder="Search for a game " />
				</div>
			</div>
			<div class="scrollar">
			<div class="generalOPtions">
			<div onclick={getAllGames} class="option">
					<div class="option-image">
					<img src={allImage} alt="" />
					</div>
					<div class="option-text">All</div>
				</div>
				<div onclick={getAllPopular} class="option">
					<div class="option-image">
					<img src={popularImage} alt="" />
					</div>
					<div class="option-text">Popular</div>
				</div>
				<div onclick={getAllNew} class="option">
					<div class="option-image">
					<img src={newImage} alt="" />
					</div>
					<div class="option-text">New</div>
				</div>
				<div onclick={getAllGames} class="option">
					<div class="option-image">
					<img src={favouriteImage} alt="" />
					</div>
					<div class="option-text">Favourite</div>
				</div>
				<div onclick={getAllGames} class="option">
					<div class="option-image">
					<img src={slotImage} alt="" />
					</div>
					<div class="option-text">Slots</div>
				</div>
				<div onclick={() => {getAllGamesForGameType(3)}} class="option">
					<div class="option-image">
					<img src={tableImage} alt="" />
					</div>
					<div class="option-text">Table</div>
				</div>
				<div onclick={() => {getAllGamesForGameType(4)}} class="option">
					<div class="option-image">
					<img src={blackjackImage} alt="" />
					</div>
					<div class="option-text">Blackjack</div>
				</div>
				<div onclick={() => {getAllGamesForGameType(5)}} class="option">
					<div class="option-image">
					<img src={rouletteImage} alt="" />
					</div>
					<div class="option-text">Roulette</div>
				</div>
				<div onclick={() => {getAllGamesForGameType(6)}} class="option">
					<div class="option-image">
					<img src={pokerImage} alt="" />
					</div>
					<div class="option-text">Poker</div>
				</div>
				<div onclick={() => {getAllGamesForGameType(7)}} class="option">
					<div class="option-image">
					<img src={scratchAndWinImage} alt="" />
					</div>
					<div class="option-text">Scratch & Win</div>
				</div>
				
			</div>
			</div>
			<div class="LandingToolbarDesktop">      
			<img  src={logoGold} alt="" class="cl"  />     
			<div class="generalOPtionsDesktop">
			
				<div onclick={getAllGames} class="option">
					<div class="option-image">
					<img src={allImage} alt="" />
					</div>
					<div class="option-text">All</div>
				</div>
				<div onclick={getAllPopular} class="option">
					<div class="option-image">
					<img src={popularImage} alt="" />
					</div>
					<div class="option-text">Popular</div>
				</div>
				<div onclick={getAllNew} class="option">
					<div class="option-image">
					<img src={newImage} alt="" />
					</div>
					<div class="option-text">New</div>
				</div>
				<div onclick={getAllGames} class="option">
					<div class="option-image">
					<img src={favouriteImage} alt="" />
					</div>
					<div class="option-text">Favourite</div>
				</div>
				<div onclick={() => {getAllGamesForGameType(2)}} class="option">
					<div class="option-image">
					<img src={slotImage} alt="" />
					</div>
					<div class="option-text">Slots</div>
				</div>
				<div onclick={() => {getAllGamesForGameType(3)}} class="option">
					<div class="option-image">
					<img src={tableImage} alt="" />
					</div>
					<div class="option-text">Table</div>
				</div>
				<div onclick={() => {getAllGamesForGameType(4)}} class="option">
					<div class="option-image">
					<img src={blackjackImage} alt="" />
					</div>
					<div class="option-text">Blackjack</div>
				</div>
				<div onclick={() => {getAllGamesForGameType(5)}} class="option">
					<div class="option-image">
					<img src={rouletteImage} alt="" />
					</div>
					<div class="option-text">Roulette</div>
				</div>
				<div onclick={() => {getAllGamesForGameType(6)}} class="option">
					<div class="option-image">
					<img src={pokerImage} alt="" />
					</div>
					<div class="option-text">Poker</div>
				</div>
				<div onclick={() => {getAllGamesForGameType(7)}} class="option">
					<div class="option-image">
					<img src={scratchAndWinImage} alt="" />
					</div>
					<div class="option-text">Scratch & Win</div>
				</div>
				
				
				
			</div>
				<div class="spacer"></div>
				<div class="searchAndLanguage">
					<input value={getSearch()} onChange={HandleSearchInput} class="SearchBar" type="text" name="" id="" placeholder="Search for a game " />
				</div>
			</div>
	
			
	
	
	
			<div class="gameListArea">
				{GamesAvailable() && (
					<For each={GamesAvailable()}>
						{(asset) =>(
								<div class="gameItem">
								<div class="gameOptions">
									{getTag(asset) && (
									<div class="badge">
										<span class={getTag(asset)}> {getTag(asset)} </span>
									</div>
									)} 
								</div>
								<div class="gameImage" onClick={async () => {LaunchGame(asset.lobbyName)}}>
									<img loading="lazy" src={asset.url}  />
								</div>
								<div class="gameName">{asset.lobbyName}</div>
							</div>
						)}
					</For>
				)}
			
			</div>
	
		</div>
	


		)}


		{GamesAvailable.error && (
			<h1>An Error Occured</h1>

		)}

   
	
	</>
)



}


export default LandingPage ; 