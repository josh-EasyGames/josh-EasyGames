import { createResource } from "solid-js";

class ResourcesService {
    private baseUrl : string  = 'https://easy-public.easygamesdemo.co.za'

    async loginUser(username :string , password : string){
        const resourceUrl =  "/api/Public/EasyGamesToken"

        const resourseAsset  = async () => (
             await fetch(`${this.baseUrl}/${resourceUrl}` , {
                method: "post" , 
                body : JSON.stringify({
                    username , password
                })
            })).json() ; 
            const [loginData] = createResource(resourseAsset) ;
            console.log(loginData)
            return loginData ;
    }

    async getImageURLS(){
                    const resourseURL = "/images"

       
         return (await fetch(`${this.baseUrl}/${resourseURL}`)).json()
        
        
    }

     getLaucherUrl(){
        const resourceUrl = "/gameLaucher"
        const resourceAsset = async () => (
            (await fetch(`${this.baseUrl}/${resourceUrl}`)).json()
        )
        const [laucherUrl] = createResource(resourceAsset) ; 
        return laucherUrl ; 
    }

    setPlayerToken(value:string){
        sessionStorage.setItem("token" , value) ; 
    }

    clearPlayerToken(){
        sessionStorage.clear() ; 
    }
    
}

export default ResourcesService ; 



