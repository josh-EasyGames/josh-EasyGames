import {  type Component } from 'solid-js';
import Loader from './Loader';
import GameLibrary from './GameLib';



const App: Component = () => {
   
  
  return (
    <GameLibrary/>
   )
};

export default App;
